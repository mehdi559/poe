# Dashboard Financier - Package d'Export

## 📋 Description du Projet

Dashboard financier personnel développé en React avec Tailwind CSS. Application moderne avec modes clair/sombre, multilingue (FR/EN/ES), et interface élégante.

## 🎨 Style et Design

### Couleurs et Thème
- **Palette principale** : Bleu (#3B82F6), Violet (#8B5CF6), Rose (#EC4899)
- **Gradients** : `from-blue-500 via-purple-500 to-pink-500`
- **Modes** : Clair et sombre avec adaptation automatique
- **Animations** : Transitions fluides, hover effects, scale transforms

### Composants UI
- **Boutons** : Rounded corners, shadows, hover effects
- **Modals** : Backdrop blur, shadows, responsive design
- **Cards** : Gradients, borders, modern styling

## 📊 Données Exportées

### Export JSON (Complet)
```json
{
  "userName": "Nom utilisateur",
  "categories": [
    {
      "id": 1,
      "name": "Alimentation",
      "budget": 300,
      "color": "#3B82F6"
    }
  ],
  "expenses": [
    {
      "id": 1,
      "date": "2024-01-15",
      "category": "Alimentation",
      "amount": 25.50,
      "description": "Courses"
    }
  ],
  "savingsGoals": [...],
  "recurringExpenses": [...],
  "debts": [...],
  "monthlyIncome": 3000,
  "selectedCurrency": "EUR",
  "initialBalance": 5000
}
```

### Export CSV (Dépenses uniquement)
```csv
Date,Catégorie,Description,Montant
2024-01-15,Alimentation,Courses,25.50
2024-01-14,Transport,Essence,45.00
```

## 🛠️ Technologies Utilisées

- **React** : Interface utilisateur
- **Tailwind CSS** : Styling et design system
- **Lucide React** : Icônes modernes
- **LocalStorage** : Persistance des données
- **JavaScript ES6+** : Logique métier

## 📁 Structure des Fichiers

### Fichiers Principaux
- `dataUtils.js` : Fonctions d'export/import
- `useFinanceManager.js` : Logique métier et gestion des données
- `financeReducer.js` : Gestion d'état avec Reducer
- `ImportExportModal.js` : Interface d'export
- `DashboardHeader.js` : Header avec menu utilisateur

### Configuration
- `package.json` : Dépendances et scripts
- `tailwind.config.js` : Configuration Tailwind CSS

## 🎯 Objectif

Créer des exports plus vivants et colorés avec :
- **Graphiques** : Visualisations des dépenses par catégorie
- **Charts** : Évolution temporelle des dépenses
- **Couleurs** : Utilisation de la palette du projet
- **Design moderne** : Gradients, ombres, animations
- **Responsive** : Adaptation mobile/desktop
- **Modes thème** : Support clair/sombre

## 💡 Suggestions d'Amélioration

1. **Export HTML** : Page web interactive avec graphiques
2. **Export PDF** : Rapport stylisé avec charts
3. **Export Excel** : Feuilles multiples avec formules
4. **Dashboard interactif** : Visualisations D3.js ou Chart.js
5. **Animations** : Transitions et micro-interactions

## 🔧 Fonctions d'Export Actuelles

### JSON Export
```javascript
exportToJSON: (data) => {
  // Crée un fichier JSON avec toutes les données
  // Format: finance-data-YYYY-MM-DD.json
}
```

### CSV Export
```javascript
exportToCSV: (data, filename) => {
  // Crée un fichier CSV avec les dépenses
  // Format: expenses-YYYY-MM-DD.csv
}
```

## 🎨 Palette de Couleurs

```css
/* Couleurs principales */
--blue-500: #3B82F6
--purple-500: #8B5CF6
--pink-500: #EC4899
--emerald-500: #10B981
--yellow-500: #EAB308

/* Gradients */
--gradient-primary: from-blue-500 via-purple-500 to-pink-500
--gradient-success: from-emerald-500 to-green-600
--gradient-warning: from-yellow-500 to-orange-500
```

## 📱 Responsive Design

- **Mobile** : < 768px
- **Tablet** : 768px - 1024px  
- **Desktop** : > 1024px

## 🌍 Internationalisation

- **Français** : Interface principale
- **Anglais** : Traductions disponibles
- **Espagnol** : Traductions disponibles 